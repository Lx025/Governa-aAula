import static org.junit.Assert.*;

import org.junit.Test;

import org.junit.Before;
import org.junit.After;

public class CalculadoraTeste {

	// Mensagem de abertura do teste
	

	@Test
	public void testeSomar() {
		int nro1 = 5;
		int nro2 = 5;
		Calculadora calc = new Calculadora();
		int resultadoEsperado = 10;
		int resultadoReal = calc.somar(nro1, nro2);
		assertEquals(resultadoEsperado, resultadoReal);
	}

	@Test
	public void testeSubtrair3de5() {
		int nro1 = 5;
		int nro2 = 3;
		Calculadora calc = new Calculadora();
		int resultadoEsperado = 2;
		int resultadoReal = calc.subtrair(nro1, nro2);
		assertEquals(resultadoEsperado, resultadoReal);
	}

	@Test
	public void testeMultiplicar3por3() {
		int nro1 = 3;
		int nro2 = 3;
		Calculadora calc = new Calculadora();
		int resultadoEsperado = 9;
		int resultadoReal = calc.multiplicar(nro1, nro2);
		assertEquals(resultadoEsperado, resultadoReal);
	}

	@Test
	public void testeDividir3por2() {
		int nro1 = 3;
		int nro2 = 2;
		Calculadora calc = new Calculadora();
		double resultadoEsperado = 1.5;
		double resultadoReal = calc.dividir(nro1, nro2);
		assertEquals(resultadoEsperado, resultadoReal, 0.5);
	}

	@Test
	public void testeSomar8com3() {
		int nro1 = 8;
		int nro2 = 3;
		Calculadora calc = new Calculadora();
		int resultadoEsperado = 11;
		int resultadoReal = calc.somar(nro1, nro2);
		assertEquals(resultadoEsperado, resultadoReal);
	}

}
