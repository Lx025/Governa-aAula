import static org.junit.Assert.*;
import org.junit.Test;
import static org.junit.Assert.assertEquals;

public class MensagemTeste {

	@Test
	public void testeCriaMesnsagemPadrao() {
		String mensagem;
		mensagem = "Pedro Bo";
		Mensagem msg = new Mensagem(mensagem);
		String retorno = msg.exibirMsg();
		assertEquals("Ola! Seja bem vindo a sua calculadora pessoal,", retorno);
		}
	
	@Test
	public void testeComplementaMensagem() {
		
		String mensagem;
		mensagem = "Pedro Bo";
		Mensagem msg = new Mensagem(mensagem);
		String mensagemRetorno;
		mensagemRetorno = msg.completarMenssagem();
		assertEquals(mensagem, mensagemRetorno); 
	}
	

}
