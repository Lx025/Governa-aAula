
public class Mensagem {
	String mensage;

	
	public Mensagem(String mensage) {
		super();
		this.mensage = mensage;
	}

	public String exibirMsg() {
		String compmens;
		compmens = "Ola! Seja bem vindo a sua calculadora pessoal,";
		System.out.print(compmens);
		return compmens;
	}
	
	public String completarMenssagem() {

		System.out.println(this.mensage + '!');
		System.out.println("Confira os resultados dos testes no painel da JUNIT!");
		return this.mensage;
	}

}
